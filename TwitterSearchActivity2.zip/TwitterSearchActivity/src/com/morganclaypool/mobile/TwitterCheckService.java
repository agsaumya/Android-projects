/**
 * 
 */
package com.morganclaypool.mobile;

import java.io.IOException;
import java.net.URLEncoder;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

/**
 * @author Saumya
 *
 */


/*
public class DisplayToast implements Runnable{
	  String mText;

	  public DisplayToast(String text){
	    mText = text;
	  }

	  public void run(){
	     Toast.makeText(TwitterCheckService.this, mText, Toast.LENGTH_SHORT).show();
	  }
	}
*/

public class TwitterCheckService extends IntentService {

	
	//private static final String TWITTER_SEARCH_API = "http://search.twitter.com/search.json?lang=en&q=";
	private static final String TWITTER_SEARCH_API = "https://api.twitter.com/1/users/show.json?screen_name=";
	private DefaultHttpClient httpClient = new DefaultHttpClient();	
	
	//private int mAppWidgetId;
    Handler mHandler = new Handler();

    public static boolean flag = false; 
	
    /** 
	   * A constructor is required, and must call the super IntentService(String)
	   * constructor with a name for the worker thread.
	   */
	  public TwitterCheckService() {
	      super("TwitterCheckService");
	      
	  }
	  	 
	  
	  @Override
	  public int onStartCommand(Intent intent, int flags, int startId) {
	      
		  if (intent.getAction().equals("Stop"))
		        stopSelf();
		  
		  Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();	      
	      
	      return super.onStartCommand(intent,flags,startId);
	  }

	  /**
	   * The IntentService calls this method from the default worker thread with
	   * the intent that started the service. When this method returns, IntentService
	   * stops the service, as appropriate.
	   */
	  @Override
	  protected void onHandleIntent(Intent intent) {
	      // Normally we would do some work here, like download a file.
	      // For our sample, we just sleep for 5 seconds.
		  
		  Bundle bundle = intent.getExtras();
		    String profileName = bundle.getString("profileName");
		    String durationString = bundle.getString("duration");
		    long duration = Integer.parseInt(durationString);
		    
		  
		    System.out.println("the profile: " + profileName + ", \n duration: " + duration);		    
		    
		    mHandler.post(new DisplayToast(profileName));
		    mHandler.post(new DisplayToast(durationString));
		    
		    int j = 0;
		    //Toast.makeText(this, profileName, Toast.LENGTH_SHORT).show();
		    //Toast.makeText(this, bundle.getString("duration"), Toast.LENGTH_SHORT).show();
		    
		  String prevTweetId = searchNewTweet(profileName);
		  if(prevTweetId == null)
			  {
			  	mHandler.post(new DisplayToast("What is your favorite site?"));
			  	stopSelf();//closes the service if the tweet username is not found.
			  }
		  else
		  {
			  while(j<5)
			  {
				  
				  if(flag) break;
				  pauseService(duration);
				  System.out.println("j=" + j);
				  String newTweetId = searchNewTweet(profileName);
				  if(newTweetId.equalsIgnoreCase(prevTweetId)) 
					  {
					  j++;
					  	continue;
					  }
				  else
				  {
					  mHandler.post(new DisplayToast("There is a new Tweet!!!"));
					  System.out.println("j2=" + j);
						stopSelf();//closes the service if the tweet username is not found.
				  }		
				  j++;
			  }			  
				  
		  }//end of else      
	      
		  stopSelf();//closes the service if the tweet username is not found.
	  }
	  
	  void pauseService(long duration)
	  {
		  
		  long endTime = System.currentTimeMillis() + duration*1000;
	      while (System.currentTimeMillis() < endTime) {
	          synchronized (this) {
	              try {
	                  wait(endTime - System.currentTimeMillis());
	              } catch (Exception e) {
	            	  
	              }
	          }
	      }//end of while
	  }//end of method
	  
	  
	  public String searchNewTweet(String profileName)
	  {
		  String resultString = get(TWITTER_SEARCH_API + URLEncoder.encode(profileName));
		  String retID=null;
		    try {
		      /*JSONArray resultJsonArray = (new JSONObject(resultString)).getJSONArray("status");
		      JSONObject jsonObject = null;*/
		    	JSONObject jsonObject = (new JSONObject(resultString)).getJSONObject("status");
		      //jsonObject = resultJsonArray.getJSONObject(0);
		     // for (int i = 0; i < resultJsonArray.length(); i++) {
		       // jsonObject = resultJsonArray.getJSONObject(i);
		        /*Tweet tweet = new Tweet();
		        tweet.user = jsonObject.getString("from_user");
		        tweet.text = jsonObject.getString("text");
		        tweet.iconUrl = jsonObject.getString("profile_image_url");
		        tweetList.add(tweet);
		        */
		        
		      retID = jsonObject.getString("id");
		        System.out.println("tweet id: " + retID);
		        return retID;
		        
		      
		    } catch (JSONException e) {
		      e.printStackTrace();
		    }
		    return retID;
	  }
	  
	  
	  @Override
	  public void onDestroy() {
	    Toast.makeText(this, "service done", Toast.LENGTH_SHORT).show();
	    //this.onDestroy();
	    flag = true;
	    super.onDestroy();
	    
	  }  
	  
	  private class DisplayToast implements Runnable{
	        String mText;

	        public DisplayToast(String text){
	            mText = text;
	        }

	        public void run(){
	            Toast.makeText(TwitterCheckService.this, mText, Toast.LENGTH_SHORT).show();
	        }
	    }
	
	  
	  private String get(String url) {
		    String responseMessage = null;
		    HttpGet httpGet = new HttpGet(url);
		    try {
		      HttpResponse getResponse = httpClient.execute(httpGet);
		      HttpEntity getResponseEntity = getResponse.getEntity();
		      if (getResponseEntity != null) {
		        responseMessage = EntityUtils.toString(getResponseEntity);
		      }
		    } catch (IOException e) {
		      httpGet.abort();
		      e.printStackTrace();
		    }
		    return responseMessage;
		  }
	  
	  
	}//end of class


