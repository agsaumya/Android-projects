package com.morganclaypool.mobile;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TwitterBookMarkActivity extends Activity {

	 private static final String TAG = TwitterBookMarkActivity.class.getName();
	 private static final String FILENAME  = "favoritetwitter.txt";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_twitter_book_mark);
		
		final Button saveTwitterButton = (Button) findViewById(R.id.saveTwitterButton);
		final Button backButton = (Button) findViewById(R.id.backButton);
		
		
		saveTwitterButton.setOnClickListener(new View.OnClickListener() {
		      public void onClick(View view) {
		        
		    	  Intent intent = new Intent();		    	  
		        intent.setClass(TwitterBookMarkActivity.this, TwitterCheckService.class);        
		        Bundle bundle = new Bundle();
		
		        
		        
		        
		        
		        final EditText favTwitNameEditText = (EditText) findViewById(R.id.favTwitNameEditText);
		        final EditText durationEditText = (EditText) findViewById(R.id.durationEditText);
		        //File file = new File(context.getFilesDir(), filename);
		        
		        String profileName = favTwitNameEditText.getText().toString();
		        String duration = durationEditText.getText().toString();
		    //    byte[] numBytes = profileName.getBytes();
		        
		        //String string = "Hello world!";
		   /*     FileOutputStream outputStream;
		      FileInputStream inputStream;
		        
		        
		        try {
		          outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
		          
		          outputStream.write(profileName.getBytes());
		          outputStream.close();
		        } catch (Exception e) {
		          e.printStackTrace();
		        }
		        
		      //  Toast.makeText(getApplicationContext(), profileName, Toast.LENGTH_SHORT).show();		        
		        
		        
		      
		        String textFromFileString  = readFromFile();
		        Toast.makeText(getApplicationContext(), textFromFileString, Toast.LENGTH_SHORT).show();
		        
		       /* String inputBuffer = "";
		        String fileBuffer="";
		        
		        try {
			          inputStream = openFileInput(filename);
			          int i = inputStream.read(numBytes);
			          fileBuffer = numBytes.toString();
			          
			          //inputStream.read(profileName.getBytes());
			          inputStream.close();
			        } catch (Exception e) {
			          e.printStackTrace();
			        }
		        
		        Toast.makeText(getApplicationContext(), fileBuffer, Toast.LENGTH_SHORT).show();		        
		        */
		        
		        
		        writeToFile(profileName); //writing to the File
		        
		        String textFromFileString  = readFromFile(); //reading from the same file
		        
		        Toast.makeText(getApplicationContext(), textFromFileString, Toast.LENGTH_SHORT).show();
		        
		        bundle.putString("profileName", profileName);
		        bundle.putString("duration", duration);
		        
		        intent.putExtras(bundle);
		        intent.setAction("start");
		        startService(intent);
		        //startActivity(intent);  //starts teh service to save the profile name (Fav Twitter Profile)
		        
		     /*   Intent saveIntent = new Intent();
		        saveIntent.setClass(TwitterBookMarkActivity.this, TwitterSearchActivity.class);        
		        Bundle bundle = new Bundle();
		       */ 
		      }
		    });
		
		
		
		backButton.setOnClickListener(new View.OnClickListener() {
		      public void onClick(View view) {
		        Intent intent = new Intent();
		        intent.setClass(TwitterBookMarkActivity.this, TwitterSearchActivity.class);        
		        	        
		        startActivity(intent);
		      }
		    });			
	}	
	
	private void writeToFile(String data) {

        try {

            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(openFileOutput(FILENAME, Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e(TAG, "File write failed: " + e.toString());
        }        

    }	
	
	private String readFromFile() {
		        String ret = "";
		        try {
		            InputStream inputStream = openFileInput(FILENAME);
		            if ( inputStream != null ) {
		                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

		                String receiveString = "";

		                StringBuilder stringBuilder = new StringBuilder();
		                while ( (receiveString = bufferedReader.readLine()) != null ) {
		
		                    stringBuilder.append(receiveString);
		                }
		                inputStream.close();
		
		                ret = stringBuilder.toString();
		
		            }
		
		        }
		
		        catch (FileNotFoundException e) {
		
		            Log.e(TAG, "File not found: " + e.toString());
		
		        } catch (IOException e) {
		
		            Log.e(TAG, "Can not read file: " + e.toString());
		
		        }		 
		
		        return ret;
		
		    }
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_twitter_book_mark, menu);
		return true;
	}

}
