package com.morganclaypool.mobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class TwitterSearchActivity extends Activity {

  
	
	
	
	@Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    final Button searchButton = (Button) findViewById(R.id.searchButton);
    final Button registerTwitterButton = (Button) findViewById(R.id.registerTwitterButton);
    final Button stopServiceButton = (Button) findViewById(R.id.stopServiceButton);
    
    searchButton.setOnClickListener(new View.OnClickListener() {
      public void onClick(View view) {
        Intent intent = new Intent();
        intent.setClass(TwitterSearchActivity.this, TweetListActivity.class);        
        Bundle bundle = new Bundle();
        final EditText keywordEditText = (EditText) findViewById(R.id.keyWordEditText);
        bundle.putString("keyword", keywordEditText.getText().toString());
        intent.putExtras(bundle);
        
        startActivity(intent);
      }
    });
    
    
    registerTwitterButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
          Intent intent = new Intent();
          intent.setClass(TwitterSearchActivity.this, TwitterBookMarkActivity.class);        
          //Bundle bundle = new Bundle();
          
          
          //intent.putExtras(bundle);
          
          startActivity(intent);
        }
      });  //end of method registerTwitterButton statement
    
    
    
    stopServiceButton.setOnClickListener(new View.OnClickListener() {
        public void onClick(View view) {
          Intent intent = new Intent();
          intent.setClass(TwitterSearchActivity.this, TwitterCheckService.class);        
          
          /*Bundle bundle = new Bundle();
          
          bundle.putString("keyword", "Stop");
          intent.putExtras(bundle);*/
          intent.setAction("Stop");
          
          stopService(intent);
        }
      });  //end of method stopServiceButton statement
       
    
  }

}