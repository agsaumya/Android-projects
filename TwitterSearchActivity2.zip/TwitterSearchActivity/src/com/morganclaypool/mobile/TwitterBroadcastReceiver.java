/**
 * 
 */
package com.morganclaypool.mobile;

/**
 * @author Saumya
 *
 */

/*
public class TwitterBroadcastReceiver {

	/**
	 * @param args
	 */
	/*public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
*/



import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

public class TwitterBroadcastReceiver extends BroadcastReceiver {

  @Override
  public void onReceive(Context context, Intent intent) {
	  
	  System.out.println("Inside Broadcast Service");
	  
	  
	  Toast.makeText(context, "Broadcast receiver", Toast.LENGTH_LONG).show();
	  
	  
	  Intent service = new Intent(context, TwitterCheckService.class);
	  Bundle bundle = new Bundle();
	  
	  bundle.putString("profileName", "agarwalsaumya");
      bundle.putString("duration", "4");
      
      intent.putExtras(bundle);
      intent.setAction("start");
	  
	  
	  context.startService(service); 
	  
	  
	  
    /*Bundle extras = intent.getExtras();
    if (extras != null) {
      String state = extras.getString(TelephonyManager.EXTRA_STATE);
      Log.w("DEBUG", state);
      if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
        String phoneNumber = extras
            .getString(TelephonyManager.EXTRA_INCOMING_NUMBER);
        Log.w("DEBUG", phoneNumber);
      }
    }*///
  }
} 