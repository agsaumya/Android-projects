package com.morganclaypool.mobile;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v4.app.NavUtils;


public class TweetDisplayActivity extends Activity {

	String keyword = "";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		// Get the message from the intent
	    Intent intent = this.getIntent();
	      
	    System.out.println("inside new activity1");
	    
		Bundle bundle = intent.getExtras();
	    Tweet tweet = new Tweet();
	    
	    keyword = bundle.getString("keyword");
	    tweet.iconUrl = bundle.getString("icon");
	    tweet.text = bundle.getString("text");
	    tweet.user = bundle.getString("user");	   	    
	    
	    System.out.println("inside new activity2");
	    
	    System.out.println("between 2 and 3: " +  tweet.iconUrl + "  " +  tweet.text + "  " + tweet.user);
	    
	    
	   // LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	    //View tweetView = inflater.inflate(R.layout.tweet, parent, false);
	    
	    setContentView(R.layout.activity_tweet_display);
	    TextView textView = (TextView) findViewById(R.id.text1);
	    
	    System.out.println("inside new activity2.555");
	    
	    
	    if(textView == null){
	    	Toast.makeText(getApplicationContext(), "NULL !", Toast.LENGTH_LONG).show();
	    }
	    else{
	     	Toast.makeText(getApplicationContext(), "HoLdS SoMeThInG  !", Toast.LENGTH_SHORT).show();
	 		
	    }
	    
	    textView.setText(tweet.user + ": " +tweet.text);
	    
	    System.out.println("inside new activity3");
	    
	
	    ImageView imageView = (ImageView) findViewById(R.id.icon1);
	    imageView.setImageDrawable(loadImageFromURL(tweet.iconUrl));	    
		System.out.println("inside new activity4");
	 //   setContentView(textView);
		//setContentView(R.layout.activity_tweet_display);
	    
		// Show the Up button in the action bar.
		//getActionBar().setDisplayHomeAsUpEnabled(true);
	}

	
	private Drawable loadImageFromURL(String url) {
	    Drawable drawable = null;
	    try {
	      InputStream is = (InputStream) new URL(url).getContent();
	      drawable = Drawable.createFromStream(is, "srcname");
	    } catch (IOException e) {
	      e.printStackTrace();
	    }
	    return drawable;
	  }

	/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_tweet_display, menu);
		return true;
	}

*/
	
	
	/** Called when the user clicks the Back button */
	  public void sendBack(View view)
	  {
		      
		        Intent intent = new Intent();
		        intent.setClass(TweetDisplayActivity.this, TweetListActivity.class);
		        intent.putExtra("keyword", keyword);
		        startActivity(intent);    
		    
	  }
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			// This ID represents the Home or Up button. In the case of this
			// activity, the Up button is shown. Use NavUtils to allow users
			// to navigate up one level in the application structure. For
			// more details, see the Navigation pattern on Android Design:
			//
			// http://developer.android.com/design/patterns/navigation.html#up-vs-back
			//
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
