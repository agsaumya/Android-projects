package com.morganclaypool.mobile;

public class Tweet {

  public String user;
  public String text;
  public String iconUrl;

}
