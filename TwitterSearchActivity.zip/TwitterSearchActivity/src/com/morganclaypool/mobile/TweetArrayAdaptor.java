package com.morganclaypool.mobile;

import java.io.*;
import java.net.URL;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class TweetArrayAdaptor extends ArrayAdapter<Tweet> {

  private final Context context;
  private final List<Tweet> tweets;  

  public TweetArrayAdaptor(Context context, List<Tweet> tweets) {
    super(context, R.layout.tweet, tweets);
    this.context = context;
    this.tweets = tweets;
  }

  /*
  public void sendTweet(View view) {
      // Do something in response to button
  
	  int position = 0;
	  System.out.println(" tweet no1 " + position);
	}
	*/
  
  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    Tweet tweet = tweets.get(position);
    View tweetView = inflater.inflate(R.layout.tweet, parent, false);
    TextView textView = (TextView) tweetView.findViewById(R.id.text);
    textView.setText(tweet.user + ": " +tweet.text);
    ImageView imageView = (ImageView) tweetView.findViewById(R.id.icon);
    imageView.setImageDrawable(loadImageFromURL(tweet.iconUrl));    
    
    //System.out.println("indis123");
    
    /*
    tweetView.setOnClickListener(new View.OnClickListener() {
      public void onClick(View view) {
        Intent intent = new Intent(); //creates an intent
        intent.setClass(context, TweetDisplayActivity.class); //forwarding class name       
        
        System.out.println("indis");
        
        Bundle bundle = new Bundle();        
        
        bundle.putString("user", tweet.user.toString());
        bundle.putString("text", tweet.text.toString());
        bundle.putString("icon", tweet.iconUrl.toString());
        intent.putExtras(bundle);
        
        
        
        context.startActivity(intent);
      }
    });
    */
    
    
    return tweetView;
  }

  private Drawable loadImageFromURL(String url) {
    Drawable drawable = null;
    try {
      InputStream is = (InputStream) new URL(url).getContent();
      drawable = Drawable.createFromStream(is, "srcname");
    } catch (IOException e) {
      e.printStackTrace();
    }
    return drawable;
  }

}