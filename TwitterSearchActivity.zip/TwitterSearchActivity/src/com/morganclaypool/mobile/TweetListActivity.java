package com.morganclaypool.mobile;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.*;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.*;


import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class TweetListActivity extends Activity {

  private static final String TWITTER_SEARCH_API = "http://search.twitter.com/search.json?lang=en&q=";
  private DefaultHttpClient httpClient = new DefaultHttpClient();
  public List<Tweet> tweetList = new ArrayList<Tweet>();
  String keyword;
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    Bundle bundle = this.getIntent().getExtras();
    keyword = bundle.getString("keyword"); //keyword = search string
    List<Tweet> tweetList2 = searchTweets(keyword);
    tweetList = tweetList2;
    System.out.println("ArrayList size: " + tweetList.size());
   
    setContentView(R.layout.tweetlist);
    
    TweetArrayAdaptor adapter = new TweetArrayAdaptor(TweetListActivity.this, tweetList2);
    ((ListView)findViewById(R.id.my_list)).setAdapter(adapter);
    
    ((ListView)findViewById(R.id.my_list)).setOnItemClickListener(new OnItemClickListener(){

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			System.out.println("inside onlistclick post: " + arg2);
			  
			  System.out.println("ArrayList size2: " + tweetList.size());
			  
			  Tweet tweet = tweetList.get(arg2);
			  Bundle bundle = new Bundle();
			  bundle.putString("user", tweet.user.toString());
		      bundle.putString("text", tweet.text.toString());
		      bundle.putString("icon", tweet.iconUrl.toString());
		      bundle.putString("keyword", keyword);
			  
			  //try
			  //{	  
				  		  
				  //Class ourClass = Class.forName("com.morganclaypool.mobile.TweetDisplayActivity");
				  //Intent ourIntent = new Intent();
				  //ourIntent.setClass(this, TweetDisplayActivity.class); //forwarding class name
		      System.out.println("this value: " + this + "  tweetdisplact value: " + TweetDisplayActivity.class);
				  Intent ourIntent = new Intent(TweetListActivity.this, TweetDisplayActivity.class);
				  //Intent ourIntent = new Intent(TweetListActivity.this, ourClass);
				  ourIntent.putExtras(bundle);
				 
				  startActivity(ourIntent);
			  	  		
		}
    	
    });
  }
  
  
  /** Called when the user clicks the Back button */
  public void sendBack(View view)
  {
	      
	        Intent intent = new Intent();
	        intent.setClass(TweetListActivity.this, TwitterSearchActivity.class);
	        intent.putExtra("keyword", keyword);
	        startActivity(intent);    
	    
  }

  
 /* 
  public void sendTweet(View view) {
      // Do something in response to button
  
	  int position = 0;
	  System.out.println(" tweet no " + position);
	  position = getSelectedItemPosition();
	  
	  System.out.println(" tweet no " + position);
	  //Intent intent = new Intent(this, TweetDisplayActivity.class);
	  //TextView editText = (TextView) findViewById(R.id.text); //findViewById is the method of Activity class
  	  	
  	//String tweetMessage = editText.getText().toString();
  	
  	//intent.putExtra(EXTRA_MESSAGE, message);
  	//startActivity(intent);
  	
  	
  }
  */
  
  
  //get the lists of tweets in the List<Tweet> 
  private List<Tweet> searchTweets(String keyword) {
    List<Tweet> tweetList = new ArrayList<Tweet>();
    String resultString = get(TWITTER_SEARCH_API + URLEncoder.encode(keyword));
    try {
      JSONArray resultJsonArray = (new JSONObject(resultString)).getJSONArray("results");
      JSONObject jsonObject = null;
      for (int i = 0; i < resultJsonArray.length(); i++) {
        jsonObject = resultJsonArray.getJSONObject(i);
        Tweet tweet = new Tweet();
        tweet.user = jsonObject.getString("from_user");
        tweet.text = jsonObject.getString("text");
        tweet.iconUrl = jsonObject.getString("profile_image_url");
        tweetList.add(tweet);
      }
    } catch (JSONException e) {
      e.printStackTrace();
    }
    return tweetList;
  }
  
  
  //get the response from the Web browser of the given URL
  private String get(String url) {
    String responseMessage = null;
    HttpGet httpGet = new HttpGet(url);
    try {
      HttpResponse getResponse = httpClient.execute(httpGet);
      HttpEntity getResponseEntity = getResponse.getEntity();
      if (getResponseEntity != null) {
        responseMessage = EntityUtils.toString(getResponseEntity);
      }
    } catch (IOException e) {
      httpGet.abort();
      e.printStackTrace();
    }
    return responseMessage;
  }
  
}